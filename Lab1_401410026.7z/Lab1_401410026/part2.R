x<-1:100
x<-x*x
y<-sum(x)
